// Assignment 1 | COMP1073 Client-Side JavaScript

/* Variables
-------------------------------------------------- */
// Constants for main button query selectors
const noun1Button = document.getElementById('noun1');
const verbButton = document.getElementById('verb');
const adjectiveButton = document.getElementById('adjective');
const noun2Button = document.getElementById('noun2');
const settingButton = document.getElementById('setting');

// Constants for p tag to display query selectors
const choosenNoun1Para = document.getElementById('choosenNoun1');
const choosenVerbPara = document.getElementById('choosenVerb');
const choosenAdjectivePara = document.getElementById('choosenAdjective');
const choosenNoun2Para = document.getElementById('choosenNoun2');
const choosenSettingPara = document.getElementById('choosenSetting');

// Constants for final buttons and p tags
const playbackButton = document.getElementById('playback');
const randomButton = document.getElementById('random');
const storyPara = document.getElementById('story');

// Variables for pre-defined arrays
const nouns1 = ['Cat', 'Dog', 'Tree', 'Car', 'Book'];
const verbs = ['Run', 'Jump', 'Read', 'Eat', 'Sleep'];
const adjectives = ['Happy', 'Sad', 'Big', 'Small', 'Fast'];
const nouns2 = ['Mountain', 'Ocean', 'City', 'Forest', 'Castle'];
const settings = ['Under the moonlight', 'In a secretive cave', 'On a deserted island', 'In a busy city', 'At the top of the world'];

// Variables for count to grab array elements
let noun1Count = 0;
let verbCount = 0;
let adjectiveCount = 0;
let noun2Count = 0;
let settingCount = 0;

/* Functions
-------------------------------------------------- */
function noun1_on_click() {
    // variable to get array element and displaying it
    choosenNoun1Para.textContent = nouns1[noun1Count];
    // if-else to change count setting
    if (noun1Count < nouns1.length - 1){
        noun1Count++;
    }
    else{
        noun1Count = 0;
    }

}

function verb_on_click() {
    choosenVerbPara.textContent = verbs[verbCount];

    if (verbCount < verbs.length - 1){
        verbCount++;
    }
    else{
        verbCount = 0;
    }
}

function adjective_on_click() {
    choosenAdjectivePara.textContent = adjectives[adjectiveCount];

    if (adjectiveCount < adjectives.length - 1){
        adjectiveCount++;
    }
    else{
        adjectiveCount = 0;
    }
}

function noun2_on_click() {
    choosenNoun2Para.textContent = nouns2[noun2Count];
    // if-else to change count setting
    if (noun2Count < nouns2.length - 1){
        noun2Count++;
    }
    else{
        noun2Count = 0;
    }

}

function setting_on_click() {
    choosenSettingPara.textContent = settings[settingCount];

    if (settingCount < settings.length - 1){
        settingCount++;
    }
    else{
        settingCount = 0;
    }
}

// concatenate the user story and display
function playback_on_click() {
    storyPara.textContent = `${choosenNoun1Para.textContent} ${choosenVerbPara.textContent} ${choosenAdjectivePara.textContent} ${choosenNoun2Para.textContent} ${choosenSettingPara.textContent}`
}

// grabbing random element from arrays, concatenate and display
function random_on_click() {
    choosenNoun1Para.textContent = nouns1[Math.floor(Math.random() * nouns1.length)];
    choosenVerbPara.textContent = verbs[Math.floor(Math.random() * verbs.length)];
    choosenNoun2Para.textContent = nouns2[Math.floor(Math.random() * nouns2.length)];
    choosenAdjectivePara.textContent = adjectives[Math.floor(Math.random() * adjectives.length)];
    choosenSettingPara.textContent = settings[Math.floor(Math.random() * settings.length)];

    playback_on_click(); //Calls the playback function to update us on the full story
}

// this is an extra function added to the assignment, a reset button that allows us to reset the story

function reset_on_click(){
    choosenNoun1Para.textContent = ' ';
    choosenVerbPara.textContent = ' ';
    choosenAdjectivePara.textContent = ' ';
    choosenNoun2Para.textContent = ' ';
    choosenSettingPara.textContent = ' ';
    storyPara.textContent = ' ';

}

/* Event Listeners
-------------------------------------------------- */

// Ok so now I am going to add some event listeners to these buttons

noun1Button.addEventListener('click', noun1_on_click);
verbButton.addEventListener('click', verb_on_click);
adjectiveButton.addEventListener('click', adjective_on_click);
noun2Button.addEventListener('click', noun2_on_click);
settingButton.addEventListener('click', setting_on_click);
